from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import HTTPBearer
from pymongo import MongoClient
from datetime import datetime

app = FastAPI()
security = HTTPBearer()

# Conexión MongoDB IPv6
client = MongoClient("mongodb://[::1]:27017")
db = client["monitoreo"]

@app.post("/api/datos")
async def recibir_datos(temp: float, hum: float, token: str = Depends(security)):
    if token.credentials != "wokwi-token-secreto":
        raise HTTPException(status_code=401, detail="Token inválido")
    
    db.datos.insert_one({
        "temp": temp,
        "hum": hum,
        "timestamp": datetime.now()
    })
    return {"status": "ok"}

@app.get("/api/ultimos_datos")
async def obtener_datos(token: str = Depends(security)):
    if token.credentials != "wokwi-token-secreto":
        raise HTTPException(status_code=401, detail="Token inválido")
    
    datos = list(db.datos.find().sort("timestamp", -1).limit(10))
    return {"datos": datos}